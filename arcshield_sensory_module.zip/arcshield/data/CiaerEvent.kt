package com.capps.arcshield.data

import com.capps.arcshield.sensory.SensoryBundle
import com.capps.arcshield.sensory.SensoryDeltaBundle
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Full CIAER+ event record.
 *
 * Cause · Intuition · Action · Effect · Result, with Pre-ENV baseline and Shadow
 * Actions as first-class siblings to action. This is the canonical ML-ingestion
 * format — every field maps directly to schema/ciaer_plus_v1.json (JSON Schema
 * Draft 2020-12).
 *
 * Shadow Actions are stored as a top-level array sibling to action (per the
 * SRK-gated elicitation policy: skip for SKILL, light for RULE, full for KNOWLEDGE).
 */
@Serializable
data class CiaerEvent(

    // ── Envelope ────────────────────────────────────────────────
    @SerialName("event_id") val eventId: String,
    @SerialName("schema_version") val schemaVersion: String = "1.0",
    @SerialName("captured_at_ms") val capturedAtMs: Long,
    @SerialName("operator_id") val operatorId: String,
    @SerialName("facility_id") val facilityId: String,
    @SerialName("line_id") val lineId: String,

    // ── Pre-ENV ─────────────────────────────────────────────────
    @SerialName("pre_env") val preEnv: PreEnvSnapshot,

    // ── Cause ───────────────────────────────────────────────────
    @SerialName("cause") val cause: Cause,

    // ── Intuition ───────────────────────────────────────────────
    @SerialName("intuition") val intuition: Intuition,

    // ── Action ──────────────────────────────────────────────────
    @SerialName("action") val action: Action,

    // ── Shadow Actions (sibling to action) ──────────────────────
    @SerialName("shadow_actions") val shadowActions: List<ShadowAction> = emptyList(),

    // ── Effect ──────────────────────────────────────────────────
    @SerialName("effect") val effect: Effect,

    // ── Result ──────────────────────────────────────────────────
    @SerialName("result") val result: Result,

    // ── Optional withhold-sample flag for reflexivity prevention ─
    @SerialName("withhold_sample") val withholdSample: Boolean = false
)

// ──────────────────────────────────────────────────────────────
// Phase: Cause
// ──────────────────────────────────────────────────────────────

@Serializable
data class Cause(
    @SerialName("phase_id") val phaseId: String,
    /** Five-channel sensory bundle captured at trigger moment. */
    @SerialName("sensory_at_trigger") val sensoryAtTrigger: SensoryBundle?,
    /** Per-channel deltas vs pre_env.sensory_baseline. */
    @SerialName("sensory_deltas") val sensoryDeltas: SensoryDeltaBundle?,
    @SerialName("sensor_readings") val sensorReadings: Map<String, Float> = emptyMap(),
    @SerialName("trend_features") val trendFeatures: Map<String, Float> = emptyMap(),
    @SerialName("sensory_annotation") val sensoryAnnotation: String? = null,
    @SerialName("visual_frame_ref") val visualFrameRef: String? = null,
    @SerialName("biometric_at_trigger") val biometricAtTrigger: BiometricSnapshot? = null,
    @SerialName("escalation_state") val escalationState: EscalationState
)

@Serializable
data class BiometricSnapshot(
    @SerialName("hr_bpm") val hrBpm: Float? = null,
    @SerialName("hrv_rmssd_ms") val hrvRmssdMs: Float? = null,
    @SerialName("activity_class") val activityClass: String? = null,
    @SerialName("gaze_dwell_s") val gazeDwellS: Float? = null,
    @SerialName("body_response") val bodyResponse: Float? = null,
    @SerialName("timestamp_ms") val timestampMs: Long
)

@Serializable
enum class EscalationState {
    @SerialName("nominal") NOMINAL,
    @SerialName("watch") WATCH,
    @SerialName("concern") CONCERN,
    @SerialName("alert") ALERT,
    @SerialName("critical") CRITICAL
}

// ──────────────────────────────────────────────────────────────
// Phase: Intuition
// ──────────────────────────────────────────────────────────────

@Serializable
data class Intuition(
    @SerialName("phase_id") val phaseId: String,
    @SerialName("voice_transcript") val voiceTranscript: String? = null,
    /** Required field — the operator's hypothesized cause. */
    @SerialName("causal_hypothesis") val causalHypothesis: String,
    @SerialName("srk_level") val srkLevel: SrkLevel,
    /** Independent biometric deviation signal. */
    @SerialName("biometric_signal") val biometricSignal: Float? = null,
    /** PIE elicitation hints surfaced to the operator at prompt time. */
    @SerialName("elicitation_hints") val elicitationHints: List<String> = emptyList(),
    /** Operator's pre-action confidence in the hypothesis (0..1). */
    @SerialName("confidence_level") val confidenceLevel: Float? = null
)

@Serializable
enum class SrkLevel {
    @SerialName("skill") SKILL,
    @SerialName("rule") RULE,
    @SerialName("knowledge") KNOWLEDGE
}

// ──────────────────────────────────────────────────────────────
// Phase: Action
// ──────────────────────────────────────────────────────────────

@Serializable
data class Action(
    @SerialName("phase_id") val phaseId: String,
    @SerialName("action_sequence") val actionSequence: List<ActionStep>,
    @SerialName("action_started_ms") val actionStartedMs: Long,
    @SerialName("action_completed_ms") val actionCompletedMs: Long? = null
)

@Serializable
data class ActionStep(
    @SerialName("step_index") val stepIndex: Int,
    @SerialName("step_label") val stepLabel: String,
    @SerialName("step_timestamp_ms") val stepTimestampMs: Long,
    @SerialName("action_type") val actionType: String? = null
)

@Serializable
data class ShadowAction(
    /** Alternative action considered but rejected. */
    @SerialName("shadow_label") val shadowLabel: String,
    /** Why the operator rejected this alternative. */
    @SerialName("rejection_reason") val rejectionReason: String? = null,
    /** SRK level at which this alternative was considered. */
    @SerialName("srk_level") val srkLevel: SrkLevel
)

// ──────────────────────────────────────────────────────────────
// Phase: Effect
// ──────────────────────────────────────────────────────────────

@Serializable
data class Effect(
    @SerialName("phase_id") val phaseId: String,
    /** Post-action sensory bundle. */
    @SerialName("sensory_post_action") val sensoryPostAction: SensoryBundle? = null,
    /** Deltas: post-action minus at-trigger. */
    @SerialName("sensory_deltas") val sensoryDeltas: SensoryDeltaBundle? = null,
    @SerialName("sensor_readings") val sensorReadings: Map<String, Float> = emptyMap(),
    @SerialName("deltas") val deltas: Map<String, Delta> = emptyMap(),
    @SerialName("visual_frame_ref") val visualFrameRef: String? = null
)

@Serializable
data class Delta(
    @SerialName("from") val from: Float,
    @SerialName("to") val to: Float,
    @SerialName("direction") val direction: String  // "improved" | "degraded" | "unchanged"
)

// ──────────────────────────────────────────────────────────────
// Phase: Result
// ──────────────────────────────────────────────────────────────

@Serializable
data class Result(
    @SerialName("phase_id") val phaseId: String,
    @SerialName("outcome_tag") val outcomeTag: OutcomeTag,
    @SerialName("prediction_match") val predictionMatch: Boolean,
    @SerialName("escalation_delta") val escalationDelta: Int,
    @SerialName("graph_weight") val graphWeight: Float,
    @SerialName("failure_mode_tag") val failureModeTag: String? = null,
    @SerialName("operator_reflection") val operatorReflection: String? = null,
    @SerialName("resolved_at_ms") val resolvedAtMs: Long
)

@Serializable
enum class OutcomeTag {
    @SerialName("resolved") RESOLVED,
    @SerialName("partial_resolution") PARTIAL_RESOLUTION,
    @SerialName("escalated") ESCALATED,
    @SerialName("no_effect") NO_EFFECT,
    @SerialName("worsened") WORSENED
}
