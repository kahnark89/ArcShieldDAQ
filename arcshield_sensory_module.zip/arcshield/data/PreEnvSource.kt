package com.capps.arcshield.data

import kotlinx.coroutines.flow.StateFlow

/**
 * Source of Pre-ENV (shift-start) context for the CIAER+ pipeline.
 *
 * Captures the operator, shift phase, material batch, and the five-channel
 * sensory baseline ONCE per shift. The result is held in [current] and read
 * by event assembly each time a CIAER event is captured.
 *
 * Implementations:
 *   - DefaultPreEnvSource (Gen 1) — combines operator login, clock-derived shift phase,
 *     barcode batch scan, and SensoryCaptureManager.captureBaseline().
 *   - NetworkedPlcPreEnvSource (Gen 2) — adds PLC-pulled batch and phase data.
 */
interface PreEnvSource {

    /** Current Pre-ENV snapshot — null until [captureShiftStart] runs successfully. */
    val current: StateFlow<PreEnvSnapshot?>

    /**
     * Capture the shift-start snapshot. Triggers SensoryCaptureManager baseline
     * capture internally. Idempotent within a shift — subsequent calls return the
     * already-captured snapshot unless [force] is true.
     */
    suspend fun captureShiftStart(
        operatorId: String,
        shiftPhase: ShiftPhase = ShiftPhase.STARTUP,
        materialBatchId: String? = null,
        shiftStartNote: String? = null,
        force: Boolean = false
    ): PreEnvSnapshot

    /** Update the material batch ID mid-shift (barcode rescan at changeover). */
    suspend fun updateMaterialBatch(materialBatchId: String)

    /** Update the recent events summary (called by event repository after each event). */
    suspend fun updateRecentEventsSummary(summary: String)

    /** Clear the snapshot at shift end. */
    suspend fun clear()
}
