package com.capps.arcshield.data

import com.capps.arcshield.sensory.SensoryBundle
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Pre-ENV (Pre-Cause Environmental) baseline context for the CIAER+ schema.
 *
 * Captured ONCE at shift start. Provides the baseline that all event-time
 * sensory deltas are computed against. Also carries non-sensory context that
 * doesn't change frame-to-frame: operator, shift, material batch.
 *
 * For PPVC Line 1 (PLC not networked), most fields are operator-supplied at login.
 * On Gen 2 with networked PLC, batch IDs and shift phase can be auto-populated.
 */
@Serializable
data class PreEnvSnapshot(
    /** Operator identifier — user_id from login. */
    @SerialName("operator_id") val operatorId: String,

    /** Shift phase derived from clock + shift schedule. */
    @SerialName("shift_phase") val shiftPhase: ShiftPhase,

    /** Current material batch ID (barcode or short-code at batch change). */
    @SerialName("material_batch_id") val materialBatchId: String? = null,

    /** Auto-generated summary of recent CIAER events this shift. */
    @SerialName("recent_events_summary") val recentEventsSummary: String? = null,

    /** Five-channel sensory baseline bundle. Drives delta computation at event time. */
    @SerialName("sensory_baseline") val sensoryBaseline: SensoryBundle? = null,

    /** Free-form operator note captured at shift start. */
    @SerialName("shift_start_note") val shiftStartNote: String? = null,

    /** Wall-clock timestamp of shift start in milliseconds since epoch. */
    @SerialName("timestamp_ms") val timestampMs: Long
)

@Serializable
enum class ShiftPhase {
    @SerialName("startup") STARTUP,
    @SerialName("steady_state") STEADY_STATE,
    @SerialName("changeover") CHANGEOVER,
    @SerialName("shutdown") SHUTDOWN,
    @SerialName("unscheduled") UNSCHEDULED
}
